const path = require('path');
const fs = require('fs-extra');
const { spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const AdmZip = require('adm-zip');

/**
 * Build APK from ZIP project (Flutter or Android Studio)
 */
async function buildFromZip(zipPath, projectType, buildType, onProgress) {
    const jobId = uuidv4();
    const tempDir = path.join(__dirname, '..', '..', 'temp', jobId);

    try {
        // Extract ZIP
        onProgress('📂 Extracting project files...');
        await fs.ensureDir(tempDir);

        const zip = new AdmZip(zipPath);
        zip.extractAllTo(tempDir, true);

        // Find project root (look for build.gradle or pubspec.yaml)
        const projectRoot = await findProjectRoot(tempDir, projectType);
        if (!projectRoot) {
            throw new Error(`Invalid ${projectType} project. Required files not found.`);
        }

        onProgress('🔍 Project detected: ' + projectType);

        // Build based on project type
        let apkPath;
        if (projectType === 'flutter') {
            apkPath = await buildFlutter(projectRoot, buildType, onProgress);
        } else {
            apkPath = await buildAndroid(projectRoot, buildType, onProgress);
        }

        // Clean up ZIP file
        await fs.remove(zipPath).catch(() => { });

        return {
            success: true,
            apkPath: apkPath,
            buildDir: tempDir
        };

    } catch (error) {
        // Cleanup on error
        await fs.remove(tempDir).catch(() => { });
        await fs.remove(zipPath).catch(() => { });

        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Find project root directory
 */
async function findProjectRoot(dir, projectType) {
    const targetFile = projectType === 'flutter' ? 'pubspec.yaml' : 'build.gradle';

    // Check current directory
    if (await fs.pathExists(path.join(dir, targetFile))) {
        return dir;
    }

    // Check subdirectories (in case ZIP has a root folder)
    const items = await fs.readdir(dir);
    for (const item of items) {
        const itemPath = path.join(dir, item);
        const stat = await fs.stat(itemPath);
        if (stat.isDirectory()) {
            if (await fs.pathExists(path.join(itemPath, targetFile))) {
                return itemPath;
            }
        }
    }

    return null;
}

/**
 * Build Flutter project
 */
async function buildFlutter(projectDir, buildType, onProgress) {
    // Clean previous build artifacts
    onProgress('🧹 Cleaning previous build...');
    await runCommand('flutter', ['clean'], projectDir).catch(() => { });

    onProgress('📦 Getting Flutter dependencies...');
    await runCommand('flutter', ['pub', 'get'], projectDir, onProgress);

    onProgress('🔨 Building Flutter APK (this may take a while)...');
    const buildArgs = buildType === 'release'
        ? ['build', 'apk', '--release', '--no-tree-shake-icons']
        : ['build', 'apk', '--debug'];

    // Start keep-alive progress updates during build
    let keepAliveStep = 0;
    const buildingMessages = [
        '🔨 Compiling Dart code...',
        '⚙️ Processing resources...',
        '📦 Packaging APK...',
        '🔧 Optimizing assets...',
        '🚀 Building native code...',
        '📱 Generating APK bundle...'
    ];

    const keepAliveInterval = setInterval(() => {
        keepAliveStep++;
        const message = buildingMessages[keepAliveStep % buildingMessages.length];
        onProgress(message);
    }, 15000); // Update every 15 seconds

    try {
        await runCommand('flutter', buildArgs, projectDir, (output) => {
            // Pass real output to progress callback
            if (output && output.trim()) {
                onProgress(output);
            }
        });
    } finally {
        clearInterval(keepAliveInterval);
    }

    onProgress('✅ Build complete! Locating APK...');

    // Find APK
    const apkDir = path.join(projectDir, 'build', 'app', 'outputs', 'flutter-apk');
    const apkName = buildType === 'release' ? 'app-release.apk' : 'app-debug.apk';
    const apkPath = path.join(apkDir, apkName);

    if (!await fs.pathExists(apkPath)) {
        throw new Error('APK file not found after build');
    }

    // Copy to output
    const outputDir = path.join(__dirname, '..', '..', 'output');
    await fs.ensureDir(outputDir);
    const finalPath = path.join(outputDir, `flutter_${Date.now()}.apk`);
    await fs.copy(apkPath, finalPath);

    return finalPath;
}

/**
 * Build Android (Gradle) project
 */
async function buildAndroid(projectDir, buildType, onProgress) {
    const isWindows = process.platform === 'win32';
    const gradleCmd = isWindows ? 'gradlew.bat' : './gradlew';
    const gradlePath = path.join(projectDir, gradleCmd);

    // Check if gradlew exists, if not use global gradle
    let useGlobalGradle = false;
    if (!await fs.pathExists(gradlePath)) {
        useGlobalGradle = true;
    } else if (!isWindows) {
        // Make gradlew executable on Unix
        await fs.chmod(gradlePath, '755');
    }

    onProgress('🔨 Running Gradle build...');
    const buildTask = buildType === 'release' ? 'assembleRelease' : 'assembleDebug';

    if (useGlobalGradle) {
        await runCommand('gradle', [buildTask, '--stacktrace'], projectDir);
    } else {
        await runCommand(gradlePath, [buildTask, '--stacktrace'], projectDir);
    }

    // Find APK
    onProgress('📦 Locating APK file...');
    const apkPath = await findApk(projectDir, buildType);

    if (!apkPath) {
        throw new Error('APK file not found after build');
    }

    // Copy to output
    const outputDir = path.join(__dirname, '..', '..', 'output');
    await fs.ensureDir(outputDir);
    const finalPath = path.join(outputDir, `android_${Date.now()}.apk`);
    await fs.copy(apkPath, finalPath);

    return finalPath;
}

/**
 * Find APK file in build outputs
 */
async function findApk(projectDir, buildType) {
    const possiblePaths = [
        path.join(projectDir, 'app', 'build', 'outputs', 'apk', buildType, `app-${buildType}.apk`),
        path.join(projectDir, 'build', 'outputs', 'apk', buildType, `app-${buildType}.apk`),
        path.join(projectDir, 'app', 'build', 'outputs', 'apk', buildType, 'app-debug.apk'),
        path.join(projectDir, 'build', 'outputs', 'apk', buildType, 'app-debug.apk'),
    ];

    for (const p of possiblePaths) {
        if (await fs.pathExists(p)) {
            return p;
        }
    }

    // Recursive search as fallback
    return await findFileRecursive(projectDir, '.apk');
}

/**
 * Recursive file search
 */
async function findFileRecursive(dir, ext, maxDepth = 5, depth = 0) {
    if (depth > maxDepth) return null;

    try {
        const items = await fs.readdir(dir);
        for (const item of items) {
            const itemPath = path.join(dir, item);
            const stat = await fs.stat(itemPath);

            if (stat.isFile() && item.endsWith(ext)) {
                return itemPath;
            }

            if (stat.isDirectory() && !item.startsWith('.') && item !== 'node_modules') {
                const found = await findFileRecursive(itemPath, ext, maxDepth, depth + 1);
                if (found) return found;
            }
        }
    } catch (e) { }

    return null;
}

/**
 * Run command with promise
 * @param {string} cmd - Command to run
 * @param {string[]} args - Command arguments
 * @param {string} cwd - Working directory
 * @param {function} onOutput - Optional callback for streaming output
 */
function runCommand(cmd, args, cwd, onOutput = null) {
    return new Promise((resolve, reject) => {
        const proc = spawn(cmd, args, {
            cwd,
            shell: true,
            env: { ...process.env }
        });

        let stdout = '';
        let stderr = '';
        let lastActivity = Date.now();

        proc.stdout.on('data', (data) => {
            stdout += data;
            lastActivity = Date.now();
            if (onOutput) {
                const lines = data.toString().split('\n').filter(l => l.trim());
                if (lines.length > 0) {
                    onOutput(lines[lines.length - 1].substring(0, 100));
                }
            }
        });

        proc.stderr.on('data', (data) => {
            stderr += data;
            lastActivity = Date.now();
        });

        proc.on('close', (code) => {
            if (code === 0) {
                resolve(stdout);
            } else {
                // Extract meaningful error message from both stdout and stderr
                const allOutput = stdout + '\n' + stderr;
                const errorLines = allOutput.split('\n').filter(l =>
                    l.includes('error:') ||
                    l.includes('Error:') ||
                    l.includes('FAILED') ||
                    l.includes('Exception') ||
                    l.includes('cannot find') ||
                    l.includes('not found')
                );

                let errorMsg;
                if (errorLines.length > 0) {
                    errorMsg = errorLines.slice(0, 5).join('\n');
                } else {
                    // Get last 10 lines as fallback
                    const lastLines = allOutput.split('\n').filter(l => l.trim()).slice(-10);
                    errorMsg = lastLines.join('\n') || `Build failed with code ${code}`;
                }

                reject(new Error(errorMsg.substring(0, 1000)));
            }
        });

        proc.on('error', (err) => {
            reject(err);
        });

        // Timeout after 30 minutes (increased from 10)
        const TIMEOUT_MS = 30 * 60 * 1000;
        const timeoutCheck = setInterval(() => {
            if (Date.now() - lastActivity > TIMEOUT_MS) {
                clearInterval(timeoutCheck);
                proc.kill();
                reject(new Error('Build timeout (30 minutes of inactivity)'));
            }
        }, 60000); // Check every minute

        proc.on('close', () => clearInterval(timeoutCheck));
    });
}

module.exports = { buildFromZip };
