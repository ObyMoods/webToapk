const fs = require('fs-extra');
const path = require('path');

/**
 * Clean up old files in a directory
 * @param {string} directory - Directory to clean
 * @param {number} maxAgeMinutes - Maximum age in minutes
 */
async function cleanupOldFiles(directory, maxAgeMinutes = 30) {
    try {
        if (!await fs.pathExists(directory)) return;

        const files = await fs.readdir(directory);
        const now = Date.now();
        const maxAge = maxAgeMinutes * 60 * 1000;

        for (const file of files) {
            const filePath = path.join(directory, file);
            const stats = await fs.stat(filePath);
            const age = now - stats.mtimeMs;

            if (age > maxAge) {
                await fs.remove(filePath);
                console.log(`🗑️ Cleaned up: ${file}`);
            }
        }
    } catch (error) {
        console.error('Cleanup error:', error.message);
    }
}

/**
 * Delete a specific file or directory
 * @param {string} targetPath - Path to delete
 */
async function deleteFile(targetPath) {
    try {
        if (await fs.pathExists(targetPath)) {
            await fs.remove(targetPath);
            return true;
        }
        return false;
    } catch (error) {
        console.error('Delete error:', error.message);
        return false;
    }
}

module.exports = {
    cleanupOldFiles,
    deleteFile
};
