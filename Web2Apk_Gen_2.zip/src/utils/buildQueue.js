/**
 * Build Queue System - Single Build Lock
 * Ensures only one build runs at a time to prevent overload
 */

class BuildQueue {
    constructor() {
        this.isBuilding = false;
        this.currentBuildChatId = null;
        this.buildStartTime = null;
    }

    /**
     * Check if a build is currently in progress
     * @returns {boolean}
     */
    isBusy() {
        return this.isBuilding;
    }

    /**
     * Get current build info
     * @returns {object|null}
     */
    getCurrentBuild() {
        if (!this.isBuilding) return null;
        return {
            chatId: this.currentBuildChatId,
            startTime: this.buildStartTime,
            duration: Date.now() - this.buildStartTime
        };
    }

    /**
     * Lock the build queue for a specific chat
     * @param {number} chatId - Chat ID of the user
     * @returns {boolean} - True if lock acquired, false if busy
     */
    acquire(chatId) {
        if (this.isBuilding) {
            return false;
        }

        this.isBuilding = true;
        this.currentBuildChatId = chatId;
        this.buildStartTime = Date.now();
        console.log(`[Queue] Build started for chat ${chatId}`);
        return true;
    }

    /**
     * Release the build lock
     * @param {number} chatId - Chat ID of the user (for verification)
     */
    release(chatId = null) {
        if (chatId && this.currentBuildChatId !== chatId) {
            console.warn(`[Queue] Attempted to release lock by wrong chat: ${chatId}, current: ${this.currentBuildChatId}`);
        }

        const duration = this.buildStartTime ? Date.now() - this.buildStartTime : 0;
        console.log(`[Queue] Build completed for chat ${this.currentBuildChatId} (${Math.round(duration / 1000)}s)`);

        this.isBuilding = false;
        this.currentBuildChatId = null;
        this.buildStartTime = null;
    }

    /**
     * Force release (for error recovery or admin)
     */
    forceRelease() {
        console.log(`[Queue] Force releasing lock for chat ${this.currentBuildChatId}`);
        this.isBuilding = false;
        this.currentBuildChatId = null;
        this.buildStartTime = null;
    }

    /**
     * Get formatted status message
     * @returns {string}
     */
    getStatusMessage() {
        if (!this.isBuilding) {
            return '✅ Server siap untuk build';
        }

        const duration = Math.round((Date.now() - this.buildStartTime) / 1000);
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;

        return `⏳ Server sedang build (${minutes}m ${seconds}s)`;
    }
}

// Singleton instance
const buildQueue = new BuildQueue();

module.exports = { buildQueue };
