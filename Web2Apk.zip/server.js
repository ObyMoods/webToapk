// --- LOAD ENVIRONMENT VARIABLES FIRST ---
require('dotenv').config();

// --- CORE DEPENDENCIES ---
const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const TelegramBot = require('node-telegram-bot-api');
const multer = require('multer');
const util = require('util');

// --- SECURITY PACKAGES ---
const rateLimit = require('express-rate-limit');
const sanitizeHtml = require('sanitize-html');

// --- LOGGING SYSTEM (WINSTON) ---
const winston = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');

// Create logs directory if not exists
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

// Winston logger configuration
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }),
        winston.format.splat(),
        winston.format.json()
    ),
    defaultMeta: { service: 'web2apk' },
    transports: [
        // Error log file (daily rotation)
        new DailyRotateFile({
            filename: path.join(logsDir, 'error-%DATE%.log'),
            datePattern: 'YYYY-MM-DD',
            level: 'error',
            maxSize: '20m',
            maxFiles: '14d'
        }),
        // Combined log file (all levels)
        new DailyRotateFile({
            filename: path.join(logsDir, 'combined-%DATE%.log'),
            datePattern: 'YYYY-MM-DD',
            maxSize: '20m',
            maxFiles: '14d'
        })
    ]
});

// Console logging for development
if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
        )
    }));
}

// --- UTILS: LOGGER (Wrapper for Winston) ---
const Logger = {
    info: (msg) => logger.info(msg),
    success: (msg) => logger.info(`✅ ${msg}`),
    warn: (msg) => logger.warn(msg),
    error: (msg) => logger.error(msg),
    build: (id, msg) => logger.info(`[BUILD:${id.substring(0, 6)}] ${msg}`)
};

// --- SECURITY: ENHANCED URL ENCRYPTION UTILITY ---
// Advanced multi-layer obfuscation to protect target URLs in generated APKs
// This makes reverse engineering significantly more difficult
const SecurityUtils = {
    // Generate dynamic key from seed (jobId + timestamp)
    generateDynamicKey(seed) {
        let hash = 0;
        for (let i = 0; i < seed.length; i++) {
            hash = ((hash << 5) - hash) + seed.charCodeAt(i);
            hash |= 0; // Convert to 32bit integer
        }
        return Math.abs(hash % 200) + 50; // Key range 50-249
    },

    // 5-Layer Encryption: XOR → Base64 → Reverse → Shift → Hex
    encryptUrl(url, seed) {
        const dynamicKey = this.generateDynamicKey(seed);
        const shiftKey = (dynamicKey % 10) + 1; // Shift 1-10

        // Layer 1: XOR with dynamic key
        let xored = [];
        for (let i = 0; i < url.length; i++) {
            xored.push(url.charCodeAt(i) ^ dynamicKey);
        }

        // Layer 2: Base64 encode
        let base64 = Buffer.from(xored).toString('base64');

        // Layer 3: Reverse string
        let reversed = base64.split('').reverse().join('');

        // Layer 4: Character shift
        let shifted = '';
        for (let i = 0; i < reversed.length; i++) {
            shifted += String.fromCharCode(reversed.charCodeAt(i) + shiftKey);
        }

        // Layer 5: Hex encode
        let hex = '';
        for (let i = 0; i < shifted.length; i++) {
            hex += shifted.charCodeAt(i).toString(16).padStart(2, '0');
        }

        return { encrypted: hex, key: dynamicKey, shift: shiftKey };
    },

    // Generate heavily obfuscated decryption code for client-side
    getDecryptionCode(encryptedData) {
        const { encrypted, key, shift } = encryptedData;

        // Random variable names generator
        const r = () => '_' + Math.random().toString(36).substring(2, 8);
        const v = {
            data: r(), k: r(), s: r(), h: r(), sh: r(),
            rv: r(), b: r(), x: r(), res: r(), fn: r(),
            i: r(), c: r(), t: r(), arr: r()
        };

        // Anti-debugging: encode key values as expressions
        const keyExpr = `(${Math.floor(key / 7)}*7+${key % 7})`;
        const shiftExpr = `(${Math.floor(shift / 3)}*3+${shift % 3})`;

        // Create obfuscated decryption code
        return `
(function(){
var ${v.data}="${encrypted}";
var ${v.k}=${keyExpr};
var ${v.s}=${shiftExpr};
var ${v.fn}=function(${v.h}){
var ${v.arr}=[];
for(var ${v.i}=0;${v.i}<${v.h}.length;${v.i}+=2){
${v.arr}.push(parseInt(${v.h}.substr(${v.i},2),16));
}
var ${v.sh}='';
for(var ${v.i}=0;${v.i}<${v.arr}.length;${v.i}++){
${v.sh}+=String.fromCharCode(${v.arr}[${v.i}]-${v.s});
}
var ${v.rv}=${v.sh}.split('').reverse().join('');
var ${v.b}=atob(${v.rv});
var ${v.res}='';
for(var ${v.i}=0;${v.i}<${v.b}.length;${v.i}++){
${v.res}+=String.fromCharCode(${v.b}.charCodeAt(${v.i})^${v.k});
}
return ${v.res};
};
window['TARGET_URL']=${v.fn}(${v.data});
})();
`.replace(/\n/g, '').replace(/\s+/g, ' ');
    }
};

// --- PROMISE WRAPPER ---
const execPromise = util.promisify(exec);

// --- CONFIGURATION MANAGER (FROM ENVIRONMENT VARIABLES) ---
const CONFIG = {
    TELEGRAM_TOKEN: process.env.TELEGRAM_TOKEN,
    OWNER_ID: process.env.OWNER_ID,
    REQUIRED_CHANNEL: process.env.REQUIRED_CHANNEL,
    PORT: process.env.PORT || 3000,
    URL: process.env.URL || 'http://localhost:3000',
    ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
    DIRS: {
        TEMP: path.join(__dirname, 'temp_projects'),
        OUTPUT: path.join(__dirname, 'public', 'downloads'),
        UPLOAD: path.join(__dirname, 'uploads'),
        DB: path.join(__dirname, 'users.json')
    }
};

// --- VALIDATE CRITICAL CONFIG ---
if (!CONFIG.TELEGRAM_TOKEN || !CONFIG.OWNER_ID) {
    console.error('❌ FATAL ERROR: Missing critical environment variables!');
    console.error('Please create .env file based on .env.example');
    process.exit(1);
}

// --- SYSTEM BOOTSTRAP ---
const app = express();
const bot = new TelegramBot(CONFIG.TELEGRAM_TOKEN, { polling: true });

// --- SECURE FILE UPLOAD CONFIGURATION ---
const upload = multer({
    dest: CONFIG.DIRS.UPLOAD,
    limits: {
        fileSize: 5 * 1024 * 1024 // Max 5MB
    },
    fileFilter: (req, file, cb) => {
        const allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
        if (allowedMimes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only JPG, PNG, WEBP allowed.'));
        }
    }
});

// --- SERVICE: ADMIN REPORTER (NEW FEATURE) ---
const AdminReporter = {
    async sendReport(source, userData, appData) {
        if (!CONFIG.OWNER_ID) return;

        const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

        const reportMsg = `
🔔 <b>NEW ACTIVITY REPORT</b>
━━━━━━━━━━━━━━━━━━
👤 <b>User Info:</b>
• ID: <code>${userData.id}</code>
• Source: <b>${source}</b>
• Link: <a href="tg://user?id=${userData.id}">View Profile</a>

📱 <b>Application Details:</b>
• Name: <b>${appData.appName}</b>
• Target: <code>${appData.targetUrl}</code>
• Job ID: <code>${appData.jobId.substring(0, 8)}...</code>

⏱ <b>Time:</b> ${timestamp}
━━━━━━━━━━━━━━━━━━
✅ <i>Build Successfully Completed</i>
`.trim();

        try {
            await bot.sendMessage(CONFIG.OWNER_ID, reportMsg, {
                parse_mode: 'HTML',
                disable_web_page_preview: true
            });
            Logger.success(`Admin report sent to ${CONFIG.OWNER_ID}`);
        } catch (e) {
            Logger.warn(`Failed to send admin report: ${e.message}`);
        }
    }
};

// --- INITIALIZATION ---
Object.values(CONFIG.DIRS).forEach(dir => {
    if (!dir.endsWith('.json') && !fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        Logger.info(`Created directory: ${dir}`);
    }
});

// --- SET BOT COMMANDS MENU ---
bot.setMyCommands([
    { command: 'start', description: '🏠 Mulai menggunakan bot' },
    { command: 'cekantrian', description: '⏳ Lihat status antrian' },
    { command: 'help', description: '❓ Bantuan & panduan' },
    { command: 'cancel', description: '❌ Batalkan proses' }
]).then(() => {
    Logger.success('Bot commands menu set successfully');
}).catch(e => {
    Logger.warn(`Failed to set bot commands: ${e.message}`);
});

// --- SERVICE: CHANNEL VERIFICATION ---
async function checkChannelMembership(userId) {
    try {
        const member = await bot.getChatMember(CONFIG.REQUIRED_CHANNEL, userId);
        const validStatuses = ['member', 'administrator', 'creator'];
        return validStatuses.includes(member.status);
    } catch (error) {
        Logger.warn(`Failed to check membership for user ${userId}: ${error.message}`);
        return false;
    }
}

// --- SERVICE: USER MANAGEMENT ---
class UserService {
    constructor() {
        this.users = new Set();
        this.loadDatabase();
    }

    loadDatabase() {
        if (fs.existsSync(CONFIG.DIRS.DB)) {
            try {
                const data = fs.readFileSync(CONFIG.DIRS.DB, 'utf8');
                this.users = new Set(JSON.parse(data));
                Logger.info(`Database loaded: ${this.users.size} users.`);
            } catch (e) {
                Logger.error("Failed to load user database.");
            }
        }
    }

    saveUser(chatId) {
        if (!chatId) return;

        // Cek apakah ini user baru
        if (!this.users.has(chatId)) {
            this.users.add(chatId);
            this.persist();
            Logger.info(`New user registered: ${chatId}`);

            // TRIGGER: Kirim Backup ke Owner karena ada user baru
            this.sendBackupToOwner(chatId);
        }
    }

    removeUser(chatId) {
        if (this.users.has(chatId)) {
            this.users.delete(chatId);
            this.persist(); // Simpan perubahan ke users.json
            Logger.warn(`🗑️ User deleted from DB (Inactive): ${chatId}`);
        }
    }

    persist() {
        try {
            fs.writeFileSync(CONFIG.DIRS.DB, JSON.stringify([...this.users]));
        } catch (e) { Logger.error("Failed to save database."); }
    }

    // --- NEW: FITUR REALTIME BACKUP ---
    async sendBackupToOwner(newUser) {
        if (!CONFIG.OWNER_ID || !fs.existsSync(CONFIG.DIRS.DB)) return;

        try {
            // Beri jeda 1 detik agar file benar-benar tersimpan sebelum dikirim
            await new Promise(resolve => setTimeout(resolve, 1000));

            const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
            const caption = `
💾 <b>REALTIME DATABASE BACKUP</b>
━━━━━━━━━━━━━━━━━━
👤 <b>New User:</b> <code>${newUser}</code>
👥 <b>Total Users:</b> <code>${this.users.size}</code>
📅 <b>Time:</b> ${timestamp}
━━━━━━━━━━━━━━━━━━
<i>File users.json terbaru terlampir otomatis.</i>
            `.trim();

            await bot.sendDocument(CONFIG.OWNER_ID, CONFIG.DIRS.DB, {
                caption: caption,
                parse_mode: 'HTML'
            });

            Logger.success(`Backup database sent to Owner (Trigger: New User ${newUser})`);
        } catch (e) {
            Logger.warn(`Failed to send backup to owner: ${e.message}`);
        }
    }

    getBroadcastList() {
        return [...this.users];
    }
}
const userService = new UserService();

// --- SERVICE: APK BUILDER ENGINE ---
class BuildEngine {
    static async generate(data, callbacks) {
        const { appName, targetUrl, iconPath, jobId } = data;
        const { onProgress, onSuccess, onError } = callbacks;

        const cleanName = (appName || "MyApp").replace(/[^a-zA-Z0-9 ]/g, "").trim() || "MyApp";
        const safeSuffix = jobId.replace(/-/g, "").substring(0, 8);
        const packageId = `com.web2apk.a${safeSuffix}`;
        const projectDir = path.join(CONFIG.DIRS.TEMP, jobId);

        const logProgress = (pct, msg) => {
            Logger.build(jobId, `${pct}% - ${msg}`);
            if (onProgress) onProgress(pct, msg);
        };

        try {
            logProgress(10, '📂 Initializing Professional Workspace...');
            await this.runCmd(`cordova create "${jobId}" ${packageId} "${cleanName}"`, CONFIG.DIRS.TEMP);

            logProgress(25, '🤖 Injecting Android Core & Plugins...');
            await this.runCmd('cordova platform add android', projectDir);
            await this.runCmd('cordova plugin add cordova-plugin-splashscreen', projectDir);
            await this.runCmd('cordova plugin add cordova-plugin-statusbar', projectDir);

            logProgress(40, '🎨 Designing UI & Assets...');

            if (iconPath && fs.existsSync(iconPath)) {
                fs.copyFileSync(iconPath, path.join(projectDir, 'icon.png'));
                fs.copyFileSync(iconPath, path.join(projectDir, 'splash.png'));
            }

            this.configureXml(projectDir, targetUrl, !!iconPath);
            this.configureManifest(projectDir);

            // [UPDATED] Passing appName dan jobId ke createSmartLoader untuk dynamic encryption
            this.createSmartLoader(projectDir, targetUrl, !!iconPath, appName, jobId);

            logProgress(60, '🔨 Compiling Gradle (High Performance Mode)...');
            await this.runCmd('cordova build android', projectDir);

            logProgress(90, '📦 Signing & Packaging APK...');
            const apkSource = path.join(projectDir, 'platforms', 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
            const finalName = `${cleanName.replace(/\s+/g, '_')}_v1.apk`;
            const apkDest = path.join(CONFIG.DIRS.OUTPUT, finalName);

            if (fs.existsSync(apkSource)) {
                fs.copyFileSync(apkSource, apkDest);
                this.cleanup(projectDir, iconPath);
                logProgress(100, '✅ Build Successful!');

                const downloadUrl = `http://localhost:${CONFIG.PORT}/downloads/${finalName}`;
                if (onSuccess) onSuccess(downloadUrl, apkDest);
            } else {
                throw new Error("APK Build failed. Output file not found.");
            }

        } catch (error) {
            Logger.error(`Build Failed [${jobId}]: ${error.message}`);
            this.cleanup(projectDir, null);
            if (onError) onError(error.message);
        }
    }

    static async runCmd(cmd, cwd) {
        try { await execPromise(cmd, { cwd }); } catch (e) { throw e; }
    }

    static configureXml(dir, url, hasIcon) {
        const file = path.join(dir, 'config.xml');
        let content = fs.readFileSync(file, 'utf8');

        const preferences = `
    <preference name="ShowSplashScreen" value="true" />
    <preference name="SplashScreen" value="screen" />
    <preference name="SplashScreenDelay" value="3000" />
    <preference name="AutoHideSplashScreen" value="true" />
    <preference name="StatusBarOverlaysWebView" value="false" />
    <preference name="StatusBarBackgroundColor" value="#000000" />
    <preference name="StatusBarStyle" value="lightcontent" />
    <allow-navigation href="*" />
    <allow-intent href="*" />
    <access origin="*" />
        `;

        content = content.replace('</widget>', `${preferences}\n</widget>`);

        if (hasIcon) {
            content = content.replace('</widget>', `    <icon src="icon.png" />\n    <splash src="splash.png" />\n</widget>`);
        }

        fs.writeFileSync(file, content);
    }

    static configureManifest(dir) {
        const file = path.join(dir, 'platforms', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
        if (fs.existsSync(file)) {
            let content = fs.readFileSync(file, 'utf8');
            if (!content.includes('android:usesCleartextTraffic')) {
                content = content.replace('<application', '<application android:usesCleartextTraffic="true"');
                fs.writeFileSync(file, content);
            }
        }
    }

    // [UPDATED] PERMANENT HEADER + 5 DETIK INTRO + IFRAME MODE
    // [FIXED] INTRO 5 DETIK + FULL SCREEN (MENGATASI BLANK PUTIH)
    // [SECURITY] URL NOW ENCRYPTED WITH 5-LAYER OBFUSCATION + DYNAMIC KEY
    static createSmartLoader(dir, targetUrl, hasIcon, appName, jobId) {
        const wwwDir = path.join(dir, 'www');
        const indexFile = path.join(wwwDir, 'index.html');

        if (hasIcon) {
            fs.copyFileSync(path.join(dir, 'icon.png'), path.join(wwwDir, 'logo.png'));
        }

        // SECURITY: Encrypt URL with 5-layer obfuscation using jobId as dynamic seed
        const encryptedData = SecurityUtils.encryptUrl(targetUrl, jobId);
        const decryptionCode = SecurityUtils.getDecryptionCode(encryptedData);

        const htmlContent = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Content-Security-Policy" content="default-src * 'unsafe-inline' 'unsafe-eval' data: gap: content:;">
    
    <title>${appName}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 0;
            font-family: 'Roboto Mono', monospace;
            height: 100vh;
            width: 100vw;
            background-color: #ffffff;
            overflow: hidden;
        }

        /* --- CONTAINER UTAMA --- */
        #app-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 9999;
            background: #fff;
            transition: opacity 0.5s ease-out;
        }

        /* --- HEADER STYLE --- */
        .app-header {
            width: 100%;
            padding: 20px 0;
            background-color: #1a1a1a;
            color: #00ff88;
            text-align: center;
            font-weight: 700;
            font-size: 18px;
            letter-spacing: 1px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            position: absolute;
            top: 0;
        }

        /* --- KONTEN TENGAH --- */
        .center-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            text-align: center;
        }

        .profile-pic {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid #1a1a1a;
            object-fit: cover;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            margin-bottom: 15px;
            animation: pulse 2s infinite;
        }

        .owner-name {
            font-size: 22px;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 5px;
        }

        .thank-you {
            font-size: 13px;
            color: #555;
            line-height: 1.5;
            margin-top: 15px;
            padding: 15px;
            background: #f4f4f4;
            border-radius: 10px;
            border-left: 4px solid #00ff88;
            max-width: 85%;
        }
        
        .loader {
            margin-top: 30px;
            width: 30px;
            height: 30px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #1a1a1a;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .status-text {
            margin-top: 10px;
            font-size: 12px;
            color: #888;
        }

        @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>

    <div id="app-container">
        <div class="app-header">
            &lt; ${appName} /&gt;
        </div>

        <div class="center-content">
            <img src="https://files.catbox.moe/c3xqcj.jpg" class="profile-pic" alt="Owner">
            <div class="owner-name">LordDzik</div>
            
            <div class="thank-you">
                Terima Kasih Atas Penggunaan<br>
                Bot Web2Apk Kami
            </div>

            <div class="loader"></div>
            <div class="status-text" id="statusText">Preparing Application...</div>
        </div>
    </div>

    <script>
        ${decryptionCode}
        const INTRO_DURATION = 5000; // 5 Detik

        function launchApp() {
            const status = document.getElementById('statusText');
            
            if (navigator.onLine) {
                status.innerText = "Connected. Launching...";
                
                // Ganti halaman sepenuhnya ke target (SOLUSI BLANK PUTIH)
                window.location.replace(TARGET_URL);
            } else {
                status.innerText = "No Internet. Retrying...";
                status.style.color = "red";
                setTimeout(launchApp, 3000);
            }
        }

        document.addEventListener('deviceready', function() {
            if (navigator.splashscreen) navigator.splashscreen.hide();
            setTimeout(launchApp, INTRO_DURATION);
        }, false);

        // Fallback
        setTimeout(() => {
            setTimeout(launchApp, INTRO_DURATION);
        }, 500);
    </script>
</body>
</html>
        `;

        fs.writeFileSync(indexFile, htmlContent);
    }

    static cleanup(projectDir, iconPath) {
        try { fs.rmSync(projectDir, { recursive: true, force: true }); } catch (e) { }
        if (iconPath) { try { if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath); } catch (e) { } }
    }
}

// --- SERVICE: QUEUE MANAGER ---
class QueueManager {
    constructor() {
        this.queue = [];
        this.isProcessing = false;
    }

    add(job) {
        this.queue.push(job);
        this.process();
        return this.queue.length;
    }

    getPosition(chatId) {
        return this.queue.findIndex(j => String(j.chatId) === String(chatId));
    }

    async process() {
        if (this.isProcessing || this.queue.length === 0) return;

        this.isProcessing = true;
        const job = this.queue.shift();

        if (job.chatId !== 'WEB_CLIENT') {
            try {
                await bot.sendMessage(job.chatId, '🚀 <b>Giliran Anda!</b>\nSistem sedang memulai pembuatan aplikasi...', { parse_mode: 'HTML' });
                await bot.sendChatAction(job.chatId, 'typing');
            } catch (e) { }
        }

        await BuildEngine.generate(job.data, job.callbacks);

        this.isProcessing = false;
        this.process();
    }

    get length() { return this.queue.length; }
}
const queueService = new QueueManager();


// ============================================================
// EXPRESS SERVER (API)
// ============================================================

// --- CORS CONFIGURATION ---
app.use(cors({
    origin: CONFIG.ALLOWED_ORIGINS,
    credentials: true
}));

app.use(express.json());
app.use(express.static('public'));

// --- RATE LIMITING MIDDLEWARE ---
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // max 5 APK per 15 minutes per IP
    message: {
        success: false,
        message: "Terlalu banyak request. Coba lagi dalam 15 menit."
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// --- HEALTH CHECK ENDPOINT ---
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        uptime: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
        queueLength: queueService.length,
        isProcessing: queueService.isProcessing,
        nodeEnv: process.env.NODE_ENV || 'development'
    });
});

// --- CREATE APK ENDPOINT (WITH SECURITY) ---
app.post('/api/create-app', apiLimiter, upload.single('appIcon'), (req, res) => {
    let { appName, targetUrl } = req.body;
    const iconPath = req.file ? req.file.path : null;

    // --- INPUT VALIDATION ---
    if (!targetUrl) {
        return res.status(400).json({ success: false, message: "Missing URL" });
    }

    // Sanitize appName (prevent XSS)
    appName = sanitizeHtml(appName || 'MyApp', {
        allowedTags: [],
        allowedAttributes: {}
    }).substring(0, 30); // Max 30 characters

    // Validate URL format
    try {
        new URL(targetUrl);
    } catch (e) {
        return res.status(400).json({
            success: false,
            message: "Invalid URL format. Must start with http:// or https://"
        });
    }

    const jobId = uuidv4();
    Logger.info(`WEB REQUEST: ${appName} (${targetUrl})`);

    queueService.add({
        chatId: 'WEB_CLIENT',
        data: { appName, targetUrl, iconPath, jobId },
        callbacks: {
            onProgress: () => { },
            onSuccess: (url, path) => {
                res.json({ success: true, downloadUrl: url });
                AdminReporter.sendReport('Web Browser', { id: 'Anonymous_Web' }, { appName, targetUrl, jobId });
                setTimeout(() => { if (fs.existsSync(path)) fs.unlinkSync(path); }, 600000);
            },
            onError: (msg) => res.status(500).json({ success: false, message: msg })
        }
    });
});

// ============================================================
// TELEGRAM BOT HANDLER
// ============================================================
const userState = {};

const UI = {
    progressBar: (pct) => {
        const filled = Math.round((pct / 10) * 1.5);
        const empty = 15 - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    },
    mainMenu: {
        inline_keyboard: [
            [{ text: '📱 BUAT APLIKASI SEKARANG', callback_data: 'action_create' }],
            [
                { text: '👤 Owner', url: 'https://t.me/const_true_co' },
                { text: '📢 Official Channel', url: 'https://t.me/Death_kings01' }
            ],
            [{ text: '💎 Support / Donasi', callback_data: 'action_support' }],
            [{ text: '👨‍💻 Credits', callback_data: 'action_credits' }]
        ]
    }
};

// /broadcast (UPDATED: Auto Remove Inactive Users)
bot.onText(/\/broadcast(?: (.+))?/, async (msg, match) => {
    if (String(msg.chat.id) !== CONFIG.OWNER_ID) return;

    const textContent = match[1];
    const isReply = msg.reply_to_message;

    if (!isReply && !textContent) {
        return bot.sendMessage(msg.chat.id, '📖 <b>Broadcast Usage:</b>\n\n1. <b>Text Broadcast:</b>\n   `/broadcast <your message>`\n\n2. <b>Forward Broadcast:</b>\n   Reply to any message and type `/broadcast`.', { parse_mode: 'HTML' });
    }

    const users = userService.getBroadcastList();
    let sent = 0;
    let removed = 0; // Counter untuk user yang dihapus

    const statusMsg = await bot.sendMessage(msg.chat.id, `📡 <b>Broadcasting to ${users.length} users...</b>`, { parse_mode: 'HTML' });

    for (const uid of users) {
        try {
            if (isReply) {
                await bot.forwardMessage(uid, msg.chat.id, msg.reply_to_message.message_id);
            } else {
                await bot.sendMessage(uid, `🔔 <b>SYSTEM ANNOUNCEMENT</b>\n\n${textContent}`, { parse_mode: 'HTML' });
            }
            sent++;
            await new Promise(resolve => setTimeout(resolve, 100)); // Rate limiting
        } catch (e) {
            const errMsg = e.message.toLowerCase();

            // DETEKSI USER INACTIVE (Blocked / Deleted Account / Kicked)
            if (errMsg.includes('blocked') || errMsg.includes('deactivated') || errMsg.includes('kicked') || errMsg.includes('chat not found')) {
                userService.removeUser(uid);
                removed++;
                Logger.warn(`User ${uid} removed: Bot Blocked/User Deactivated.`);
            } else {
                Logger.warn(`Broadcast failed for user ${uid}: ${e.message}`);
            }
        }
    }

    await bot.editMessageText(`✅ <b>Broadcast Complete</b>\n\n👥 <b>Total Target:</b> ${users.length}\n🚀 <b>Success:</b> ${sent}\n🗑️ <b>Auto Removed:</b> ${removed} (Blocked/Inactive)\n❌ <b>Failed (Other):</b> ${users.length - sent - removed}`, {
        chat_id: msg.chat.id,
        message_id: statusMsg.message_id,
        parse_mode: 'HTML'
    });
});

// /start
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Check channel membership first
    const isMember = await checkChannelMembership(userId);

    if (!isMember) {
        // User belum join channel
        const joinKeyboard = {
            inline_keyboard: [
                [{ text: '📢 Join Channel', url: 'https://t.me/Death_kings01' }],
                [{ text: '✅ Verifikasi', callback_data: 'verify_membership' }]
            ]
        };
        const safeName = msg.from.first_name.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return bot.sendPhoto(chatId, 'https://raw.githubusercontent.com/ObyMoods/killtoken/main/images1.jpeg', {
            caption: `👋 <b>Selamat Datang, ${safeName}!</b>\n\n⚠️ <b>Akses Terbatas</b>\n\nUntuk menggunakan bot ini, Anda harus bergabung dengan channel official kami terlebih dahulu.\n\n📢 <b>Channel:</b> @Death_kings01\n\n<i>Setelah join, klik tombol Verifikasi di bawah.</i>`,
            parse_mode: 'HTML',
            reply_markup: joinKeyboard
        });
    }

    // User sudah join, lanjutkan seperti biasa
    userService.saveUser(chatId);
    delete userState[chatId];

    const safeName = msg.from.first_name.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    bot.sendPhoto(chatId, 'https://raw.githubusercontent.com/ObyMoods/killtoken/main/images1.jpeg', {
        caption: `👋 <b>Selamat Datang, ${safeName}!</b>\n\n🤖 <b>Web2Apk Pro Bot</b> adalah solusi instant mengubah website menjadi aplikasi Android.\n\n✨ <i>Fitur Premium:</i>\n• Tanpa Iklan\n• Proses Cepat\n• Custom Icon Support\n\n👇 <b>Mulai project Anda sekarang:</b>\nGunakan /cekantrian untuk melihat status.`,
        parse_mode: 'HTML',
        reply_markup: UI.mainMenu
    });
});

// /cekantrian
bot.onText(/\/cekantrian|\/queue/, (msg) => {
    const chatId = msg.chat.id;
    const pos = queueService.getPosition(chatId);

    let text = "";
    if (pos !== -1) {
        text = `⏳ <b>Status Project Anda</b>\n\n🔢 Posisi Antrian: <b>${pos + 1}</b>\n🚀 Estimasi: Sedang menunggu giliran...`;
    } else {
        const total = queueService.length;
        const serverStatus = queueService.isProcessing ? "🔴 SIBUK (Sedang Build)" : "🟢 ONLINE (Idle)";
        text = `ℹ️ <b>Server Status</b>\n\n🖥 Status: <b>${serverStatus}</b>\n👥 Total Antrian: <b>${total} Users</b>\n\n<i>Anda tidak memiliki antrian aktif.</i>`;
    }
    bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
});

// /help
bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    const helpText = `
📚 <b>PANDUAN WEB2APK BOT</b>
━━━━━━━━━━━━━━━━━━

<b>📱 Cara Membuat APK:</b>
1. Klik tombol "BUAT APLIKASI SEKARANG"
2. Masukkan nama aplikasi
3. Masukkan URL website target
4. (Opsional) Upload icon custom
5. Tunggu proses build selesai (~3-5 menit)

<b>⚙️ Commands:</b>
/start - Mulai bot & tampilkan menu
/cekantrian - Cek status antrian
/help - Lihat panduan ini
/cancel - Batalkan proses yang sedang berjalan

<b>💡 Tips:</b>
• URL harus dimulai dengan http:// atau https://
• Nama aplikasi maksimal 30 karakter
• Icon sebaiknya kotak (512x512px)
• Format icon: JPG/PNG/WEBP, max 5MB

<b>❓ Butuh Bantuan?</b>
Hubungi: @const_true_co
Channel: @Death_kings01

━━━━━━━━━━━━━━━━━━
<i>Powered by Node.js + Cordova</i>
    `.trim();
    bot.sendMessage(chatId, helpText, { parse_mode: 'HTML' });
});

// /cancel
bot.onText(/\/cancel/, (msg) => {
    const chatId = msg.chat.id;
    delete userState[chatId];
    bot.sendMessage(chatId, '❌ <b>Proses Dibatalkan</b>\n\nSemua input telah dihapus. Silakan mulai lagi dengan /start', { parse_mode: 'HTML' });
});

// GANTI BAGIAN INI (Sekitar baris 567 - 594)
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    if (msg.from) userService.saveUser(chatId);

    const text = msg.text; // Bisa undefined jika user kirim stiker/foto
    const state = userState[chatId];

    // Jika tidak ada state, atau pesan adalah command (diawali /), atau TEXT KOSONG (undefined), abaikan
    if (!state || (text && text.startsWith('/'))) return;

    if (state.step === 'WAITING_NAME') {
        // --- PERBAIKAN UTAMA DISINI ---
        // Jika user mengirim stiker/foto saat diminta nama, beritahu user dan return agar tidak crash
        if (!text) {
            return bot.sendMessage(chatId, '⚠️ Mohon kirimkan nama aplikasi dalam bentuk Teks, bukan stiker atau gambar.');
        }

        if (text.length > 30) return bot.sendMessage(chatId, '⚠️ Nama terlalu panjang. Maksimal 30 karakter.');

        state.data.appName = text;
        state.step = 'WAITING_URL';
        bot.sendMessage(chatId, '🔗 <b>Masukkan URL Website</b>\n\nContoh:\n• <code>https://google.com</code>\n• <code>https://tokoku.com</code>', { parse_mode: 'HTML' });

    } else if (state.step === 'WAITING_URL') {
        // Pastikan input adalah teks sebelum cek regex
        if (!text) {
            return bot.sendMessage(chatId, '⚠️ Mohon kirimkan URL dalam bentuk Teks.');
        }

        const urlRegex = /^(http|https):\/\/[^ "]+$/;
        if (!urlRegex.test(text)) return bot.sendMessage(chatId, '❌ <b>URL Tidak Valid!</b>\nPastikan menggunakan <code>http://</code> atau <code>https://</code>.', { parse_mode: 'HTML' });

        state.data.targetUrl = text;
        state.step = 'CONFIRM';
        const confirmKeyboard = {
            inline_keyboard: [
                [{ text: '✅ Proses Sekarang', callback_data: 'confirm_yes' }],
                [{ text: '✏️ Edit Data', callback_data: 'confirm_no' }]
            ]
        };
        bot.sendMessage(chatId, `📑 <b>Review Project</b>\n\n📱 <b>App Name:</b> ${state.data.appName}\n🌐 <b>Target URL:</b> ${state.data.targetUrl}\n\nApakah data sudah benar?`, { parse_mode: 'HTML', reply_markup: confirmKeyboard });
    }
});

bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;
    if (!userState[chatId]) userState[chatId] = { step: 'IDLE', data: {} };
    const state = userState[chatId];

    bot.answerCallbackQuery(query.id);

    switch (data) {
        case 'verify_membership':
            const isMember = await checkChannelMembership(query.from.id);

            if (isMember) {
                userService.saveUser(chatId);
                delete userState[chatId];

                bot.deleteMessage(chatId, query.message.message_id).catch(() => { });
                const safeName = query.from.first_name.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                bot.sendPhoto(chatId, 'https://raw.githubusercontent.com/ObyMoods/killtoken/main/images1.jpeg', {
                    caption: `✅ <b>Verifikasi Berhasil!</b>\n\n👋 Selamat datang, ${safeName}!\n\n🤖 <b>Web2Apk Pro Bot</b> adalah solusi instant mengubah website menjadi aplikasi Android.\n\n✨ <i>Fitur Premium:</i>\n• Tanpa Iklan\n• Proses Cepat\n• Custom Icon Support\n\n👇 <b>Mulai project Anda sekarang:</b>\nGunakan /cekantrian untuk melihat status.`,
                    parse_mode: 'HTML',
                    reply_markup: UI.mainMenu
                });
            } else {
                bot.answerCallbackQuery(query.id, {
                    text: '❌ Anda belum join channel. Silakan join terlebih dahulu!',
                    show_alert: true
                });
            }
            break;
        case 'action_support':
            bot.sendPhoto(chatId, 'https://raw.githubusercontent.com/ObyMoods/killtoken/main/images1.jpeg', {
                caption: `💎 <b>Premium Support</b>\n\nTerima kasih telah menggunakan layanan kami. Dukungan Anda sangat berarti agar server tetap hidup.\n\n<i>~ LordDzik</i>`, parse_mode: 'HTML'
            });
            break;
        case 'action_credits':
            const creditsMsg = `
👨‍💻 <b>CREDITS & DEVELOPER TEAM</b>
━━━━━━━━━━━━━━━━━━

<b>🎯 Lead Developer:</b>
👤 <a href="tg://user?id=1946241897">LordDzik</a>
• Creator & Maintainer
• Backend Architecture
• Bot Development

<b>🤝 Support Team:</b>
👥 <a href="https://t.me/const_true_co">@const_true_co</a>
• Technical Support
• Community Management
• Quality Assurance

━━━━━━━━━━━━━━━━━━

<b>🙏 Terima Kasih Khusus:</b>
Kepada semua pengguna yang telah mempercayai dan menggunakan Web2Apk Bot. Kontribusi dan feedback Anda sangat berharga untuk pengembangan aplikasi ini.

<b>📢 Official Channel:</b>
@Death_kings01

<i>Made with by the Web2Apk Team</i>
            `.trim();

            bot.sendPhoto(chatId, 'https://raw.githubusercontent.com/ObyMoods/killtoken/main/images1.jpeg', {
                caption: creditsMsg,
                parse_mode: 'HTML',
                disable_web_page_preview: false
            });
            break;
        case 'action_create':
            state.step = 'WAITING_NAME';
            state.data = {};
            bot.sendMessage(chatId, '🖊️ <b>Nama Aplikasi</b>\nSilakan ketik nama aplikasi yang diinginkan:', { parse_mode: 'HTML' });
            break;
        case 'confirm_no':
            delete userState[chatId];
            bot.sendMessage(chatId, '🔄 Proses dibatalkan. Silakan mulai lagi dari menu utama.');
            break;
        case 'confirm_yes':
            bot.deleteMessage(chatId, query.message.message_id).catch(() => { });
            state.step = 'WAITING_ICON';
            const iconKb = {
                inline_keyboard: [
                    [{ text: '📤 Upload Icon (Custom)', callback_data: 'icon_yes' }],
                    [{ text: '⏩ Gunakan Default', callback_data: 'icon_no' }]
                ]
            };
            bot.sendMessage(chatId, '🎨 <b>Customization</b>\nApakah Anda ingin menggunakan logo/icon sendiri?', { parse_mode: 'HTML', reply_markup: iconKb });
            break;
        case 'icon_no':
            bot.deleteMessage(chatId, query.message.message_id).catch(() => { });
            addToQueue(chatId, state.data, null);
            break;
        case 'icon_yes':
            bot.deleteMessage(chatId, query.message.message_id).catch(() => { });
            state.step = 'WAITING_ICON_UPLOAD';
            bot.sendMessage(chatId, '📤 <b>Upload Gambar</b>\nKirimkan file gambar (JPG/PNG). Disarankan rasio 1:1 (Kotak).');
            break;
    }
});

bot.on('photo', async (msg) => {
    const chatId = msg.chat.id;
    const state = userState[chatId];

    if (state?.step === 'WAITING_ICON_UPLOAD') {
        const loading = await bot.sendMessage(chatId, '⏳ <i>Downloading resources...</i>', { parse_mode: 'HTML' });
        bot.sendChatAction(chatId, 'upload_photo');

        try {
            const fileId = msg.photo[msg.photo.length - 1].file_id;
            const dlPath = await bot.downloadFile(fileId, CONFIG.DIRS.UPLOAD);
            const finalPath = path.join(CONFIG.DIRS.UPLOAD, `icon_${uuidv4()}.jpg`);
            fs.renameSync(dlPath, finalPath);

            bot.deleteMessage(chatId, loading.message_id).catch(() => { });
            addToQueue(chatId, state.data, finalPath);
        } catch (e) {
            bot.sendMessage(chatId, '❌ Gagal mengunduh gambar. Silakan coba lagi atau gunakan default.');
        }
    }
});

async function addToQueue(chatId, data, iconPath) {
    delete userState[chatId];
    const jobId = uuidv4();

    const pos = queueService.length + 1;
    const isBusy = queueService.isProcessing || queueService.length > 0;

    const msgText = isBusy
        ? `⏳ <b>Masuk Antrian (Urutan #${pos})</b>\nMohon bersabar, sistem sedang memproses permintaan lain.`
        : `🚀 <b>Permintaan Diterima!</b>\nMemulai inisialisasi build server...`;

    const sentMsg = await bot.sendMessage(chatId, msgText, { parse_mode: 'HTML' });
    const msgId = sentMsg.message_id;

    queueService.add({
        chatId,
        data: { ...data, iconPath, jobId },
        callbacks: {
            onProgress: (pct, txt) => {
                if (pct % 20 === 0 || pct === 5 || pct === 100) {
                    const bar = UI.progressBar(pct);
                    bot.editMessageText(
                        `🛠 <b>Building Application...</b>\n\n${bar} <b>${pct}%</b>\n<code>${txt}</code>`,
                        { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }
                    ).catch(() => { });
                }
            },
            onSuccess: async (url, filePath) => {
                AdminReporter.sendReport('Telegram Bot', { id: chatId }, { appName: data.appName, targetUrl: data.targetUrl, jobId });

                try {
                    await bot.editMessageText(`✅ <b>Build Completed!</b>\nUploading APK to Telegram...`, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' });
                    await bot.sendChatAction(chatId, 'upload_document');

                    await bot.sendDocument(chatId, filePath, {
                        caption: `📦 <b>${data.appName}</b>\n🔗 <code>${data.targetUrl}</code>\n\n✅ <i>Verified Build by Web2Apk Pro</i>`,
                        parse_mode: 'HTML'
                    });

                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

                } catch (err) {
                    bot.sendMessage(chatId, `⚠️ <b>Upload Error</b>\nFile APK terlalu besar untuk bot.\n\n📥 <b>Link Download (Exp 10m):</b>\n${url}`, { parse_mode: 'HTML' });
                    setTimeout(() => { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); }, 600000);
                }
            },
            onError: (err) => {
                bot.editMessageText(`❌ <b>Build Failed</b>\n\nError Log:\n<pre>${err}</pre>`, { chat_id: chatId, message_id: msgId, parse_mode: 'HTML' }).catch(() => { });
            }
        }
    });
}

app.listen(CONFIG.PORT, () => {
    console.log(`
    =========================================
     🚀 WEB2APK PRO SERVER | ONLINE
     ---------------------------------------
     📡 Port    : ${CONFIG.PORT}
     📡 URL     : ${CONFIG.URL}
     🤖 Bot     : Active
     👑 Owner   : ${CONFIG.OWNER_ID} (Reporting ON)
     📢 Channel : ${CONFIG.REQUIRED_CHANNEL} (Force Join ON)
    =========================================
    `);
});